# Cookbook

Practical recipes for common agent setups.

## Recipes

- [Research Agent](./research-agent.md)
- [Data Extraction Agent](./data-extraction-agent.md)

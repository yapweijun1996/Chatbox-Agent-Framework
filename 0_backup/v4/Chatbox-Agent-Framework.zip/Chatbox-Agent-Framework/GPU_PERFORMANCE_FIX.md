# GPU 性能问题修复方案

> 说明：本优化仅针对 Demo UI，不影响核心 Agent Framework。

## 问题总结

在 MacBook Air M4 上，网页打开时 GPU 使用率飙升到 90%，关闭后降到 10%。

### 根本原因

1. **过度使用 `backdrop-filter`** - 在 16 处使用毛玻璃效果，严重消耗 GPU
2. **5 个无限循环动画** - 持续触发 GPU 重绘
3. **复杂的多层渐变和阴影** - 每帧都需要 GPU 计算
4. **大量的 transform/transition** - 创建过多合成层

---

## 优化策略

### 1. 减少/优化 `backdrop-filter` 使用

**影响最大的位置：**
- `sidebar.css`: `blur(32px)` → 减少到 `blur(12px)` 或移除
- `composer.css`: `blur(26px)` → 减少到 `blur(10px)` 或移除
- `top-bar.css`: `blur(18px)` → 减少到 `blur(8px)` 或移除

**建议：**
- 保留最关键的毛玻璃效果（如弹出菜单）
- 其他地方用半透明背景替代
- 模糊半径控制在 10px 以内

### 2. 优化/禁用无限循环动画

**需要处理的动画：**
1. `base.css` line 59: `drift` 70s 动画（页面背景网格）
2. `composer.css` line 146: `sendPulse` 1.8s 动画
3. `sidebar.css` line 120: `pulse-glow` 3s 动画
4. `top-bar.css` line 241: `pulse-dot` 2s 动画
5. `debug.css` line 354: `pulse-blue` 2s 动画

**建议：**
- 完全移除背景 drift 动画（用户感知不明显）
- 将其他脉冲动画改为 hover 触发，而非持续运行
- 或者增加 `animation-play-state: paused` 默认状态

### 3. 简化渐变和阴影

**优化方向：**
- 减少渐变层数（目前有多个 4 层渐变）
- 简化 box-shadow（避免多重阴影）
- 移除不必要的 `saturate()` 滤镜

### 4. 优化 CSS 性能属性

**添加性能提示：**
```css
/* 关键元素添加 */
.sidebar, .debug-drawer, .composer-box, .top-bar {
    contain: layout style paint;
    will-change: auto; /* 避免过度使用 will-change */
}
```

---

## 实施优先级

### 🚨 **高优先级（立即修复）**

1. ✅ 减少所有 `backdrop-filter` 的模糊半径到 ≤10px
2. ✅ 移除 `base.css` 的 drift 背景动画
3. ✅ 将所有无限循环动画改为仅在 hover 时触发

### ⚠️ **中优先级**

4. 简化多层渐变，每个元素最多 2 层
5. 减少 box-shadow 使用，合并多重阴影

### 💡 **低优先级（渐进优化）**

6. 添加 CSS containment
7. 优化动画使用 `transform` 和 `opacity` 而非其他属性
8. 考虑添加性能偏好设置（让用户选择高性能/高视觉模式）

---

## 预期效果

实施高优先级修复后，GPU 使用率应该从 **90% 降到 20-30%**。

完成所有优化后，应该能降到 **10-15%** 或更低。

---

## 相关文件

需要修改的 CSS 文件：
- `demo/styles/base.css`
- `demo/styles/sidebar.css`
- `demo/styles/composer.css`
- `demo/styles/top-bar.css`
- `demo/styles/debug.css`
- `demo/styles/chat.css`
- `demo/styles/memory.css`

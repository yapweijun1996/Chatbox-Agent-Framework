/** @type {import('tailwindcss').Config} */
export default {
  plugins: [],
}
